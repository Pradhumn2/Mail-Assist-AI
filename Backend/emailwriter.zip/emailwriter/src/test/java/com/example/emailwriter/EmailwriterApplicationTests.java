package com.example.emailwriter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailwriterApplicationTests {

	@Test
	void contextLoads() {
	}

}
